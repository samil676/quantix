
let totalCatches = 0;

const fishTypes = [
  { name: "고래 🐋", reward: 100, chance: 0.05 },
  { name: "상어 🦈", reward: 50, chance: 0.1 },
  { name: "다랑어 🐟", reward: 10, chance: 0.25 },
  { name: "문어 🐙", reward: 0, chance: 0.2 },
  { name: "랍스터 🦞", reward: 0, chance: 0.15 },
  { name: "해삼", reward: 0, chance: 0.1 },
  { name: "조개", reward: 0, chance: 0.1 },
  { name: "새우 🦐", reward: 0, chance: 0.05 }
];

function getRandomFish() {
  const rand = Math.random();
  let sum = 0;
  for (let fish of fishTypes) {
    sum += fish.chance;
    if (rand <= sum) return fish;
  }
  return fishTypes[fishTypes.length - 1];
}

function showBonus(text, amount) {
  const div = document.getElementById("result");
  div.innerHTML += `<p style="color: gold;">${text}</p>`;
}

document.getElementById("fishButton").addEventListener("click", () => {
  const fish = getRandomFish();
  totalCatches++;

  const sfx = document.getElementById("sfx");
  sfx.play();

  const resultDiv = document.getElementById("result");
  resultDiv.innerHTML = `${fish.name}를(을) 낚았습니다!${fish.reward ? ` (+${fish.reward} WLD)` : ""}`;

  if (totalCatches % 100 === 0) showBonus("다랑어 🐟 보너스 +10 WLD", 10);
  if (totalCatches % 300 === 0) showBonus("상어 🦈 보너스 +50 WLD", 50);
  if (totalCatches % 500 === 0) showBonus("고래 🐋 보너스 +100 WLD", 100);
});
